/* 
 * File:   main.cpp
 * Author: Jesus galeano
 *
 * Created on July 14, 2015, 12:10 PM
 * purpose:
 */

//system Libraries
#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;
//user libraries

//global constants

//function prototypes
int example(int, int&);

//execution begins here
int main(int argc, char** argv) {
//declare variables
    
    //initialize and prompt for input
    
    //process  the inputs 
    
    //output the results 
    
    
    
    //exit stage right
    return 0;
}
/******************************************************************************
 *                Example Function
 ******************************************************************************
 * purpose: 
 *         show how to comment a function
 * input:
 *       a-> example input
 * input - output:
 *       b-> example input - output pass by reference
 * output:
 *       c-> example return
 ******************************************************************************/
int example(int a, int &b ){
    //declare a variable c
    int c; 
    //process
    
    //output
}