/* 
 * File:   main.cpp
 * Author: Jesus Galeano
 *
 * Created on June 27, 2015, 7:56 PM
 * purpose: Homework
 */

//System Libraries

#include <cstdlib>
#include <iomanip
#include < iostream> //File I/O

using namespace std; //std namespace -> iostream

//User libraries 

//Global Constants 

// Function Prototypes 

// Execution Begins Here

/*
 * 
 */
mian(int argc, char** argv {
    //Declare Variables Here
   
    //Input Values here
    
    //Process input here
   
    
    //output
   
   
    cuot<"Hello World"<<endl;
    
    // Exit Stage Right 
    
    return 0;
}

