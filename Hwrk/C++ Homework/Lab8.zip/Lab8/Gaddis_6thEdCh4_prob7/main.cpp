/* 
 * File:   main.cpp
 * Author: Jesus Galeano
 *
 * Created on July 2, 2015, 1:23 PM
 * Purpose: Homework
 */

#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;
//user libraries 

//global constants 

//function prototypes 

//execution begins here 
int main(int argc, char** argv) {
  //declare variables 
    int num ;
    int sec ;
    int min ;
    int hr  ;
    int day ;
    int week;
    int mnth;
    int year;
    
    //calculate
    
    sec = num%60;
    num/=60;
    min=nnum
    cout<<" please enter a  number for seconds to convert  "<<endl;
    cin>>num;
    
   
    cout<<num%year<<" months";
    
    cout<<num%mnth<<" weeks";
    
    cout<<num%week<<" days";
    
    cout<<num%day<<" hours";
   
    cout<<num%hr <<" minutes";
    
    cout<<num/min<<num%min<<" seconds"<<endl;
    return 0;
}

